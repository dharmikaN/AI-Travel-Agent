import json

from agents.llm_client import GeminiClient
from agents.utils import extract_json


class BudgetAgent:
    def __init__(self):
        self.llm = GeminiClient()

    def calculate_budget(
        self,
        total_budget,
        cities,
        days,
        travelers,
        itinerary=None
    ):
        """
        Calculate a realistic trip budget.

        The budget is treated as a HARD LIMIT.
        Gemini estimates reasonable costs, while Python
        performs the final calculations.
        """

        prompt = f"""
You are a travel cost estimation assistant.

Estimate a LOW-COST but REALISTIC budget for this exact trip.

==================================================
HARD BUDGET CONSTRAINT
==================================================

Maximum total budget: ₹{total_budget}

The final estimated cost MUST stay within this budget
whenever reasonably possible.

This is a budget-conscious trip.

Prefer:
- Budget hotels / homestays
- Public transportation
- Train or bus for inter-city travel
- Affordable local food
- Free or low-cost attractions
- Minimal paid activities

Avoid:
- Luxury hotels
- Private cabs unless necessary
- Expensive restaurants
- Unnecessary paid attractions

Cities:
{cities}

Days:
{days}

Travelers:
{travelers}

Itinerary:
{json.dumps(itinerary, ensure_ascii=False)}

==================================================
COST ESTIMATION
==================================================

Estimate:

1. Inter-city transportation for the whole group
2. Accommodation per night for the whole group
3. Food per day for the whole group
4. Attraction entry fees for the whole group
5. Local transportation per day for the whole group

Return numbers only.

Do NOT include currency symbols.

Return ONLY this JSON:

{{
    "transportation": 0,
    "hotel_per_night": 0,
    "food_per_day": 0,
    "activities": 0,
    "local_transport_per_day": 0
}}
"""

        raw = extract_json(
            self.llm.generate(prompt)
        )

        transportation = max(
            0,
            float(raw.get("transportation", 0))
        )

        hotel_per_night = max(
            0,
            float(raw.get("hotel_per_night", 0))
        )

        food_per_day = max(
            0,
            float(raw.get("food_per_day", 0))
        )

        activities = max(
            0,
            float(raw.get("activities", 0))
        )

        local_transport_per_day = max(
            0,
            float(raw.get("local_transport_per_day", 0))
        )

        # Number of hotel nights
        nights = max(0, days - 1)

        hotel = hotel_per_night * nights
        food = food_per_day * days
        local_transport = (
            local_transport_per_day * days
        )

        total = (
            transportation
            + hotel
            + food
            + activities
            + local_transport
        )

        total_budget = float(total_budget)

        remaining = total_budget - total

        return {
            "total_budget": round(total_budget, 2),
            "transportation": round(transportation, 2),
            "hotel": round(hotel, 2),
            "food": round(food, 2),
            "activities": round(activities, 2),
            "local_transport": round(
                local_transport,
                2
            ),
            "total_expense": round(total, 2),
            "remaining_budget": round(
                remaining,
                2
            ),
            "status": (
                "WITHIN BUDGET"
                if remaining >= 0
                else "OVER BUDGET"
            ),
        }
