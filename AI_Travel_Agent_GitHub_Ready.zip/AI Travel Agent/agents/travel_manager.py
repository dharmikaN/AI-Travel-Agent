from agents.llm_parser import parse_travel_request
from agents.destination_agent import DestinationAgent
from agents.budget_agent import BudgetAgent
from agents.itinerary_agent import ItineraryAgent
from agents.review_agent import ReviewAgent
from agents.constraint_validator import ConstraintValidator

from config.settings import MAX_REPLAN_ATTEMPTS


class TravelManager:

    def __init__(self):

        self.destination_agent = DestinationAgent()

        self.budget_agent = BudgetAgent()

        self.itinerary_agent = ItineraryAgent()

        self.review_agent = ReviewAgent()

        self.validator = ConstraintValidator()

        self.max_replan_attempts = MAX_REPLAN_ATTEMPTS

    def create_travel_plan(self, user_request):

        # ---------------------------------
        # 1. Parse request
        # ---------------------------------

        requirements = parse_travel_request(
            user_request
        )

        start_city = requirements.get(
            "start_city"
        )

        required_cities = requirements[
            "required_cities"
        ]

        destination_cities = requirements[
            "destination_cities"
        ]

        days = requirements["days"]

        travelers = requirements[
            "travelers"
        ]

        budget = requirements[
            "budget"
        ]

        interests = requirements[
            "interests"
        ]

        # ---------------------------------
        # 2. Build destination catalogue
        # ---------------------------------

        destinations = {}

        for city in required_cities:

            destinations[city] = (
                self.destination_agent.find_destinations(
                    city,
                    interests
                )
            )

        # ---------------------------------
        # 3. Generate + review + replan
        # ---------------------------------

        feedback = None

        last = None

        for attempt in range(
            1,
            self.max_replan_attempts + 1
        ):

            # -----------------------------
            # Generate itinerary
            # -----------------------------

            itinerary = (
                self.itinerary_agent.create_itinerary(
                    required_cities,
                    days,
                    travelers,
                    interests,
                    destinations,
                    start_city=start_city,
                    replanning_feedback=feedback,
                )
            )

            # -----------------------------
            # Calculate budget
            # -----------------------------

            budget_result = (
                self.budget_agent.calculate_budget(
                    budget,
                    required_cities,
                    days,
                    travelers,
                    itinerary,
                )
            )

            # -----------------------------
            # Deterministic validation
            # -----------------------------

            
            validation = self.validator.validate(
                itinerary=itinerary,
                required_cities=required_cities,
                required_days=days,
                total_budget=budget,
                total_expense=budget_result["total_expense"],
                destinations=destinations,
)

            # -----------------------------
            # AI quality review
            # -----------------------------

            review = (
                self.review_agent.review_plan(
                    total_budget=budget,
                    total_expense=budget_result[
                        "total_expense"
                    ],
                    itinerary=itinerary,
                    required_cities=required_cities,
                    interests=interests,
                    required_days=days,
                    travelers=travelers,
                    validation_result=validation,
                )
            )

            # -----------------------------
            # Save result
            # -----------------------------

            last = {
                "status": review["status"],
                "attempt": attempt,
                "requirements": requirements,
                "destinations": destinations,
                "itinerary": itinerary,
                "budget": budget_result,
                "review": review,
                "validation": validation,
            }

            # -----------------------------
            # Success
            # -----------------------------

            if ( validation["valid"] and review["status"] == "VALID"):
                return last

            # -----------------------------
            # Replanning feedback
            # -----------------------------

            feedback = (
                "Previous itinerary was rejected.\n\n"
                f"Hard validation issues:\n"
                f"{validation['issues']}\n\n"
                f"Review issues:\n"
                f"{review['issues']}\n\n"
                f"Suggestions:\n"
                f"{review['suggestions']}\n\n"
                "You MUST preserve:\n"
                f"- {days} days\n"
                f"- Required cities: {required_cities}\n"
                f"- Travelers: {travelers}\n"
                f"- Maximum budget: ₹{budget}\n"
            )

        return last