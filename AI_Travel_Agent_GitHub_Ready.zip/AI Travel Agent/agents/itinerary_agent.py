from agents.llm_client import GeminiClient
from agents.utils import extract_json


class ItineraryAgent:
    def __init__(self):
        self.llm = GeminiClient()

    def create_itinerary(
        self,
        required_cities,
        days,
        travelers,
        interests,
        destinations,
        start_city=None,
        replanning_feedback=None,
    ):
        prompt = f"""
You are an expert travel itinerary planner.

Create a practical {days}-day itinerary for {travelers} travelers.

==================================================
HARD CONSTRAINTS
==================================================

1. The itinerary MUST contain exactly {days} days.

2. Required cities:
{required_cities}

3. Starting city:
{start_city}

4. Every required city MUST appear at least once.

5. Use ONLY places listed in DESTINATIONS.

6. NEVER invent, rename, or substitute an attraction.

7. An attraction MUST only be used in the city where it
   appears in DESTINATIONS.

8. NEVER place a Bengaluru attraction on a Mysuru day,
   and NEVER place a Mysuru attraction on a Bengaluru day.

9. Before returning the itinerary, verify every sightseeing
   activity against the DESTINATIONS catalogue for that
   day's city.

10. If an activity belongs to another city, REMOVE it and
    replace it with an attraction from the current city's
    DESTINATIONS.

11. Group attractions that are in the same city together.

12. Prioritize these interests:
{interests}

13. Do not create unnecessary backtracking between cities.

14. If previous review feedback is provided, you MUST correct
    every problem mentioned in that feedback.

15. If the previous plan exceeded the budget, create a
    significantly more budget-friendly itinerary.

16. When replanning because of budget problems:
    - Prefer free attractions.
    - Avoid unnecessary paid attractions.
    - Avoid expensive activities.
    - Keep transportation simple.
    - Avoid unnecessary inter-city movement.
    - Do not add extra destinations.
    - Do not increase the number of activities just to fill the day.

17. Preserve the required cities, number of days, travelers,
    and interests.

18. A transit activity such as "Transfer to Mysuru" is allowed
    when moving between cities and should not be treated as
    a sightseeing attraction.

==================================================
CITY / ROUTE RULE
==================================================

The itinerary should begin in the start city:

{start_city}

Then move through the required cities in a logical order.

For example, if:

Start city = Bengaluru
Required cities = ['Bengaluru', 'Mysuru']

a sensible route is:

Bengaluru
    ↓
Bengaluru
    ↓
Bengaluru → Mysuru
    ↓
Mysuru
    ↓
Mysuru

Once the itinerary moves from the starting city to the next
required city, do not return to the previous city unless
explicitly required by the user's request.

All sightseeing activities after the transfer MUST belong
to the current city.
==================================================
IMPORTANT
==================================================

Activities must come directly from DESTINATIONS.

If an attraction is not present in DESTINATIONS, DO NOT use it.

A transfer activity may be included when moving between required
cities.

Do not add hotels, restaurants, shopping malls, airports, or
other places unless they are explicitly present in DESTINATIONS.

==================================================
DESTINATIONS
==================================================

{destinations}

==================================================
PREVIOUS REVIEW FEEDBACK
==================================================

{replanning_feedback or "None"}

==================================================
OUTPUT FORMAT
==================================================

Return ONLY valid JSON.

Use exactly this structure:

{{
  "1": {{
    "city": "City Name",
    "activities": [
      "Activity 1",
      "Activity 2"
    ]
  }},
  "2": {{
    "city": "City Name",
    "activities": [
      "Activity 1",
      "Activity 2"
    ]
  }}
}}

Do not include markdown.
Do not include explanations.
Do not include ```json.
"""

        raw_itinerary = self.llm.generate(prompt)

        itinerary = extract_json(raw_itinerary)

        return self._normalize(
            itinerary,
            required_cities,
            days,
        )

    def _normalize(
        self,
        itinerary,
        required_cities,
        days,
    ):
        if not isinstance(itinerary, dict):
            raise ValueError(
                "Itinerary response must be a JSON object."
            )

        normalized = {}

        for day in range(1, days + 1):

            item = itinerary.get(
                str(day),
                itinerary.get(day)
            )

            if not isinstance(item, dict):
                raise ValueError(
                    f"Missing itinerary for day {day}."
                )

            # ---------------------------------------------
            # City
            # ---------------------------------------------

            city = str(
                item.get("city", "")
            ).strip()

            if not city:
                raise ValueError(
                    f"Missing city for day {day}."
                )

            # ---------------------------------------------
            # Activities
            # ---------------------------------------------

            activities = item.get(
                "activities",
                []
            )

            if not isinstance(activities, list):
                raise ValueError(
                    f"Activities for day {day} must be a list."
                )

            cleaned_activities = []

            for activity in activities:

                activity = str(
                    activity
                ).strip()

                if activity:
                    cleaned_activities.append(
                        activity
                    )

            if not cleaned_activities:
                raise ValueError(
                    f"Day {day} has no activities."
                )

            # ---------------------------------------------
            # Keep maximum of 3 activities
            # ---------------------------------------------

            cleaned_activities = (
                cleaned_activities[:3]
            )

            normalized[str(day)] = {
                "city": city,
                "activities": cleaned_activities,
            }

        return normalized