class DestinationAgent:
    """Curated destination catalogue. Easy to replace with a Places/Maps API later."""

    CATALOG = {
        "Bengaluru": [
            {"name": "Lalbagh Botanical Garden", "cost": 40, "tags": ["gardens", "nature"]},
            {"name": "Cubbon Park", "cost": 0, "tags": ["gardens", "nature", "free"]},
            {"name": "Bangalore Palace", "cost": 300, "tags": ["palace", "history"]},
            {"name": "Vidhana Soudha", "cost": 0, "tags": ["architecture", "free"]},
            {"name": "ISKCON Temple Bengaluru", "cost": 0, "tags": ["culture", "spiritual"]},
        ],
        "Mysuru": [
            {"name": "Mysore Palace", "cost": 200, "tags": ["palace", "history"]},
            {"name": "Chamundi Hill", "cost": 0, "tags": ["nature", "culture", "free"]},
            {"name": "Brindavan Gardens", "cost": 100, "tags": ["gardens", "nature"]},
            {"name": "Devaraja Market", "cost": 0, "tags": ["markets", "food", "culture", "free"]},
            {"name": "St. Philomena's Cathedral", "cost": 0, "tags": ["architecture", "history", "free"]},
        ],
        "Chennai": [
            {"name": "Marina Beach", "cost": 0, "tags": ["beach", "nature", "free"]},
            {"name": "Kapaleeshwarar Temple", "cost": 0, "tags": ["culture", "history", "free"]},
            {"name": "Fort St. George", "cost": 100, "tags": ["history"]},
        ],
        "Hyderabad": [
            {"name": "Charminar", "cost": 25, "tags": ["history", "architecture"]},
            {"name": "Golconda Fort", "cost": 25, "tags": ["history", "architecture"]},
            {"name": "Hussain Sagar Lake", "cost": 0, "tags": ["nature", "free"]},
        ],
        "Mumbai": [
            {"name": "Gateway of India", "cost": 0, "tags": ["architecture", "history", "free"]},
            {"name": "Marine Drive", "cost": 0, "tags": ["nature", "free"]},
            {"name": "Chhatrapati Shivaji Maharaj Terminus", "cost": 0, "tags": ["architecture", "history", "free"]},
        ],
    }

    def find_destinations(self, city: str, interests=None):
        city_key = self._match_city(city)
        places = self.CATALOG.get(city_key, [])
        interests = {str(x).lower() for x in (interests or [])}
        if not interests:
            return places
        ranked = sorted(
            places,
            key=lambda p: sum(tag in interests or any(tag in i for i in interests) for tag in p["tags"]),
            reverse=True,
        )
        return ranked

    def _match_city(self, city):
        wanted = city.strip().casefold()
        for key in self.CATALOG:
            if key.casefold() == wanted:
                return key
        return city.strip().title()
