class ConstraintValidator:

    def validate(
        self,
        itinerary,
        required_cities,
        required_days,
        total_budget,
        total_expense,
        destinations=None,
    ):
        issues = []

        # ---------------------------------------------------------
        # 1. Basic itinerary validation
        # ---------------------------------------------------------
        if not isinstance(itinerary, dict):
            return {
                "valid": False,
                "issues": ["Itinerary must be a dictionary."]
            }

        # ---------------------------------------------------------
        # 2. Number of days
        # ---------------------------------------------------------
        if len(itinerary) != required_days:
            issues.append(
                f"Itinerary has {len(itinerary)} days; "
                f"required {required_days}."
            )

        # ---------------------------------------------------------
        # 3. Required cities
        # ---------------------------------------------------------
        itinerary_cities = {
            str(item.get("city", "")).strip().casefold()
            for item in itinerary.values()
            if isinstance(item, dict)
        }

        for city in required_cities:
            normalized_city = str(city).strip().casefold()

            if normalized_city not in itinerary_cities:
                issues.append(
                    f"Required city missing: {city}."
                )

        # ---------------------------------------------------------
        # 4. Build destination/activity catalogue
        # ---------------------------------------------------------
        activity_catalogue = {}

        if destinations:

            for city, places in destinations.items():

                normalized_city = str(city).strip().casefold()

                activity_catalogue[normalized_city] = set()

                if isinstance(places, list):

                    for place in places:

                        if isinstance(place, dict):

                            name = place.get("name", "")

                        else:
                            name = place

                        if name:
                            activity_catalogue[
                                normalized_city
                            ].add(
                                str(name).strip().casefold()
                            )

        # ---------------------------------------------------------
        # 5. Validate each day
        # ---------------------------------------------------------
        for day, item in itinerary.items():

            if not isinstance(item, dict):

                issues.append(
                    f"Day {day} is invalid."
                )

                continue

            city = str(
                item.get("city", "")
            ).strip()

            activities = item.get(
                "activities",
                []
            )

            # -----------------------------------------------------
            # Missing city
            # -----------------------------------------------------
            if not city:

                issues.append(
                    f"Day {day} has no city."
                )

            # -----------------------------------------------------
            # Invalid activities structure
            # -----------------------------------------------------
            if not isinstance(activities, list):

                issues.append(
                    f"Day {day} activities must be a list."
                )

                continue

            # -----------------------------------------------------
            # Empty day
            # -----------------------------------------------------
            if not activities:

                issues.append(
                    f"Day {day} has no activities."
                )

                continue

            # -----------------------------------------------------
            # Number of activities
            # -----------------------------------------------------
            #
            # We normally expect 2-3 activities per day.
            # A transfer day may have fewer activities, so we
            # only flag completely unreasonable days.
            #
            if len(activities) > 4:

                issues.append(
                    f"Day {day} has too many activities "
                    f"({len(activities)})."
                )

            # -----------------------------------------------------
            # Validate activities against catalogue
            # -----------------------------------------------------
            normalized_city = city.casefold()

            known_activities = activity_catalogue.get(
                normalized_city
            )

            if known_activities:

                for activity in activities:

                 # Convert activity to normalized text
                    activity_text = str(activity).strip()

                    # Remove optional price information:
                    # "Lalbagh Botanical Garden (₹40)"
                    activity_name = (
                        activity_text
                        .split("(")[0]
                        .strip()
                        .casefold()
                    )

                    # -------------------------------------------------
                    # Allow travel / transit activities
                    # -------------------------------------------------
                    transit_keywords = (
                        "travel",
                        "travelling",
                        "traveling",
                        "transfer",
                        "journey",
                        "drive",
                        "train",
                        "bus",
                        "depart",
                        "departure",
                        "arrival",
                        "transit",
                    )

                    is_transit = activity_name.startswith(
                        transit_keywords
                    )

                    # Transit activities are not attractions,
                    # so they should not be checked against
                    # the destination catalogue.
                    if is_transit:
                        continue

                    # -------------------------------------------------
                    # Validate normal activities
                    # -------------------------------------------------
                    if activity_name not in known_activities:

                        issues.append(
                            f"Day {day}: "
                            f"Unknown activity '{activity}' "
                            f"for city '{city}'."
                        )

        # ---------------------------------------------------------
        # 6. Budget validation
        # ---------------------------------------------------------
        if total_expense > total_budget:

            issues.append(
                f"Plan exceeds budget by "
                f"₹{total_expense - total_budget:.0f}."
            )

        # ---------------------------------------------------------
        # 7. Duplicate activities
        # ---------------------------------------------------------
        activity_counts = {}

        for item in itinerary.values():

            if not isinstance(item, dict):
                continue

            activities = item.get(
                "activities",
                []
            )

            if not isinstance(activities, list):
                continue

            for activity in activities:

                normalized = (
                    str(activity)
                    .split("(")[0]
                    .strip()
                    .casefold()
                )

                if not normalized:
                    continue

                activity_counts[normalized] = (
                    activity_counts.get(
                        normalized,
                        0
                    ) + 1
                )

        duplicates = [
            activity
            for activity, count
            in activity_counts.items()
            if count > 1
        ]

        # Two or more duplicated activities means the itinerary
        # is probably not sufficiently diverse.
        if len(duplicates) >= 2:

            issues.append(
                "Too many repeated activities: "
                + ", ".join(duplicates)
            )

        # ---------------------------------------------------------
        # 8. Return validation result
        # ---------------------------------------------------------
        return {
            "valid": len(issues) == 0,
            "issues": issues,
        }