import json

from agents.llm_client import GeminiClient
from agents.utils import extract_json


class ReviewAgent:

    def __init__(self):
        self.llm = GeminiClient()

    def review_plan(
        self,
        total_budget,
        total_expense,
        itinerary,
        required_cities,
        interests,
        required_days,
        travelers,
        validation_result,
    ):

        hard_issues = validation_result["issues"]

        prompt = f"""
You are a travel-plan quality reviewer.

Evaluate the following itinerary for quality.

Budget:
₹{total_budget}

Estimated expense:
₹{total_expense}

Required cities:
{required_cities}

Days:
{required_days}

Travelers:
{travelers}

Interests:
{interests}

Itinerary:
{json.dumps(itinerary, ensure_ascii=False)}

HARD CONSTRAINT ISSUES:
{hard_issues}

Check for:

- logical day ordering
- excessive repetition
- reasonable number of activities
- alignment with user interests
- practical travel flow
- sensible suggestions

IMPORTANT:

Hard constraint issues are authoritative.

If HARD CONSTRAINT ISSUES is not empty,
the final status MUST be INVALID.

Return ONLY JSON:

{{
  "status": "VALID",
  "issues": [],
  "suggestions": []
}}
"""

        result = extract_json(
            self.llm.generate(prompt)
        )

        model_issues = result.get("issues", [])
        suggestions = result.get("suggestions", [])

        all_issues = list(
            dict.fromkeys(
                hard_issues
                + [str(issue) for issue in model_issues]
            )
        )

        status = (
            "INVALID"
            if all_issues
            else "VALID"
        )

        return {
            "status": status,
            "issues": all_issues,
            "suggestions": [
                str(suggestion)
                for suggestion in suggestions
            ],
        }