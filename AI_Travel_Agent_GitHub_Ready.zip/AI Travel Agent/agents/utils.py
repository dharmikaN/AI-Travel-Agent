import json
import re
from typing import Any


def extract_json(text: str) -> Any:
    """
    Parse JSON even when an LLM accidentally wraps it
    in Markdown code fences or surrounding text.
    """

    if not text:
        raise ValueError(
            "The model returned an empty response."
        )

    text = text.strip()

    # Remove Markdown code fences
    text = re.sub(
        r"^```(?:json)?\s*",
        "",
        text,
        flags=re.IGNORECASE,
    )

    text = re.sub(
        r"\s*```$",
        "",
        text,
    )

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try to locate a JSON object
    object_match = re.search(
        r"\{.*\}",
        text,
        re.DOTALL,
    )

    if object_match:
        try:
            return json.loads(
                object_match.group(0)
            )
        except json.JSONDecodeError:
            pass

    # Try to locate a JSON array
    array_match = re.search(
        r"\[.*\]",
        text,
        re.DOTALL,
    )

    if array_match:
        try:
            return json.loads(
                array_match.group(0)
            )
        except json.JSONDecodeError:
            pass

    raise ValueError(
        "The model did not return valid JSON."
    )


def require_keys(data, keys):
    missing = [
        key
        for key in keys
        if key not in data
    ]

    if missing:
        raise ValueError(
            "Missing required fields: "
            + ", ".join(missing)
        )

    return data