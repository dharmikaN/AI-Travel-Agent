from agents.llm_client import GeminiClient
from agents.utils import extract_json, require_keys


class TravelRequestParser:
    def __init__(self):
        self.llm = GeminiClient()

    def parse(self, user_request: str) -> dict:
        prompt = f"""
You are a strict travel-request parser.

Extract the user's travel requirements.

IMPORTANT:
If the user says:
"from Bengaluru to Mysuru"

then:
- start_city = "Bengaluru"
- destination_cities = ["Mysuru"]
- required_cities = ["Bengaluru", "Mysuru"]

The starting city MUST be included in required_cities.

If the user simply says:
"visit Bengaluru and Mysuru"

then:
- start_city = null
- destination_cities = ["Bengaluru", "Mysuru"]
- required_cities = ["Bengaluru", "Mysuru"]

Return ONLY JSON:

{{
  "start_city": null,
  "destination_cities": [],
  "required_cities": [],
  "days": 0,
  "travelers": 0,
  "budget": 0,
  "interests": [],
  "notes": ""
}}

Rules:
- days, travelers and budget must be positive numbers.
- budget is INR.
- Convert phrases such as "25k" to 25000.
- Do not invent cities.
- Do not invent interests.
- required_cities must contain every city that must appear in the final itinerary.
- If a start city is explicitly given, it MUST be in required_cities.
- Keep city names in normal title case.
- interests should be short phrases.
- Return ONLY valid JSON.
- No Markdown.

User request:
{user_request}
"""

        data = extract_json(self.llm.generate(prompt))

        require_keys(
            data,
            [
                "start_city",
                "destination_cities",
                "required_cities",
                "days",
                "travelers",
                "budget",
                "interests",
            ],
        )

        data["days"] = int(data["days"])
        data["travelers"] = int(data["travelers"])
        data["budget"] = float(data["budget"])

        if data["days"] <= 0:
            raise ValueError("Days must be positive.")

        if data["travelers"] <= 0:
            raise ValueError("Travelers must be positive.")

        if data["budget"] <= 0:
            raise ValueError("Budget must be positive.")

        if not data["required_cities"]:
            raise ValueError("At least one required city is needed.")

        # Normalize city names
        data["required_cities"] = [
            str(city).strip().title()
            for city in data["required_cities"]
        ]

        data["destination_cities"] = [
            str(city).strip().title()
            for city in data["destination_cities"]
        ]

        if data["start_city"]:
            data["start_city"] = str(data["start_city"]).strip().title()

            # Safety check: start city must always be required
            if data["start_city"] not in data["required_cities"]:
                data["required_cities"].insert(0, data["start_city"])

        return data


def parse_travel_request(user_request):
    return TravelRequestParser().parse(user_request)