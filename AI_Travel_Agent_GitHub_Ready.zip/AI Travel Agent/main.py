from agents.travel_manager import TravelManager

def print_result(result):
    print("\n" + "=" * 60)
    print("FINAL TRAVEL PLAN")
    print("=" * 60)
    req = result["requirements"]
    print(f"Cities: {', '.join(req['required_cities'])}")
    print(f"Days: {req['days']} | Travelers: {req['travelers']}")
    print(f"Budget: ₹{req['budget']:,.0f}")

    for day, item in result["itinerary"].items():
        print(f"\nDay {day} — {item['city']}")
        for activity in item["activities"]:
            print(f"  • {activity}")

    b = result["budget"]
    print("\nBUDGET")
    print("-" * 60)
    for key in ["transportation", "hotel", "food", "activities", "local_transport"]:
        print(f"{key.replace('_',' ').title():20} ₹{b[key]:,.0f}")
    print(f"{'Total expense':20} ₹{b['total_expense']:,.0f}")
    print(f"{'Remaining':20} ₹{b['remaining_budget']:,.0f}")
    print(f"Status: {result['status']}")

    review = result["review"]
    if review["issues"]:
        print("\nIssues:")
        for x in review["issues"]:
            print("  -", x)
    if review["suggestions"]:
        print("\nSuggestions:")
        for x in review["suggestions"]:
            print("  -", x)

if __name__ == "__main__":
    print("AI TRAVEL AGENT")
    print("Example: Plan a 5 day trip from Bengaluru to Mysuru for 2 people under ₹25,000, interested in gardens and palaces.")
    request = input("\nEnter your travel request:\n> ").strip()
    try:
        result = TravelManager().create_travel_plan(request)
        print_result(result)
    except Exception as exc:
        print(f"\nERROR: {exc}")
        print("Check your .env file and make sure GEMINI_API_KEY is configured.")
