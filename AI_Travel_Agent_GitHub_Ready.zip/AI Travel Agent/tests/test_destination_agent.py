from agents.destination_agent import DestinationAgent

def test_bengaluru_destinations():
    places = DestinationAgent().find_destinations("Bengaluru")
    assert places
    assert any(p["name"] == "Cubbon Park" for p in places)

def test_unknown_city_returns_empty():
    assert DestinationAgent().find_destinations("Unknown City") == []
