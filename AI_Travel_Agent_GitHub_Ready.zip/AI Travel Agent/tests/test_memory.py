from memory.memory_store import MemoryStore

def test_memory_roundtrip(tmp_path):
    path = tmp_path / "history.json"
    store = MemoryStore(path)
    store.save("test trip", {"status": "VALID"})
    assert store.latest()["request"] == "test trip"
