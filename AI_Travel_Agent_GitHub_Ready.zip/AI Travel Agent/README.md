# AI Travel Agent — Complete Version

## Architecture

```text
User
  ↓
Travel Request Parser (Gemini)
  ↓
Destination Agent
  ↓
Itinerary Agent (Gemini)
  ↓
Budget Agent (Gemini)
  ↓
Review Agent (Gemini + deterministic checks)
  ↓
If invalid → feedback → Itinerary Agent (up to 3 attempts)
  ↓
Final plan + JSON memory
```

## Features added

- Natural-language trip request parsing
- Curated destination catalogue with interests and indicative entry costs
- Day-by-day itinerary generation
- Budget estimation
- Deterministic hard-constraint validation
- LLM quality review
- Automatic replanning
- Persistent local trip history
- Streamlit web interface
- JSON export
- Basic automated tests
- Environment-based configuration

## Setup

1. Open a terminal in this project folder.
2. Create a fresh virtual environment:

```bash
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

3. Install packages:

```bash
pip install -r requirements.txt
```

4. Copy `.env.example` to `.env` and put your Gemini API key in it.

5. Run the web app:

```bash
streamlit run app.py
```

Or run the CLI:

```bash
python main.py
```

Run tests:

```bash
pytest
```

## Important design note

The destination agent currently uses a small curated catalogue. This makes the project reliable and demo-friendly. The next production upgrade would be replacing/augmenting it with a live Places/Maps provider and adding live hotel/transport pricing.

Never commit `.env` or your API key to GitHub.
