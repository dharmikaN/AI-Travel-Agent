import json
from datetime import datetime, timezone
from pathlib import Path
from config.settings import MEMORY_FILE

class MemoryStore:
    def __init__(self, path=MEMORY_FILE):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text("[]", encoding="utf-8")

    def save(self, request, result):
        history = self.load()
        history.append({
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "request": request,
            "status": result.get("status"),
            "result": result,
        })
        self.path.write_text(json.dumps(history, indent=2, ensure_ascii=False), encoding="utf-8")

    def load(self):
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError):
            return []

    def latest(self):
        items = self.load()
        return items[-1] if items else None
