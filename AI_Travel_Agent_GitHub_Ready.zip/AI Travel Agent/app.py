import json
import streamlit as st
from agents.travel_manager import TravelManager
from memory.memory_store import MemoryStore

st.set_page_config(page_title="AI Travel Agent", page_icon="✈️", layout="wide")
st.title("✈️ AI Travel Agent")
st.caption("Parser → Destination → Itinerary → Budget → Review → Replanning")

request = st.text_area(
    "Describe your trip",
    placeholder="Plan a 5 day trip from Bengaluru to Mysuru for 2 people under ₹25,000. I like gardens, palaces and markets.",
    height=120,
)

if st.button("Create travel plan", type="primary", use_container_width=True):
    if not request.strip():
        st.warning("Please enter a travel request.")
    else:
        with st.spinner("AI agents are working..."):
            try:
                result = TravelManager().create_travel_plan(request)
                MemoryStore().save(request, result)
                st.session_state["result"] = result
            except Exception as exc:
                st.error(str(exc))

result = st.session_state.get("result")
if result:
    req = result["requirements"]
    b = result["budget"]
    st.success(f"Plan status: {result['status']}")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Days", req["days"])
    c2.metric("Travelers", req["travelers"])
    c3.metric("Budget", f"₹{req['budget']:,.0f}")
    c4.metric("Estimated cost", f"₹{b['total_expense']:,.0f}")

    st.subheader("Day-by-day itinerary")
    for day, item in result["itinerary"].items():
        with st.expander(f"Day {day} — {item['city']}", expanded=True):
            for activity in item["activities"]:
                st.write("•", activity)

    st.subheader("Budget breakdown")
    st.json({
        "Transportation": b["transportation"],
        "Hotel": b["hotel"],
        "Food": b["food"],
        "Activities": b["activities"],
        "Local transport": b["local_transport"],
        "Total": b["total_expense"],
        "Remaining": b["remaining_budget"],
    })

    review = result["review"]
    if review["issues"]:
        st.subheader("Review issues")
        for issue in review["issues"]:
            st.error(issue)
    if review["suggestions"]:
        st.subheader("Suggestions")
        for suggestion in review["suggestions"]:
            st.info(suggestion)

    st.download_button(
        "Download plan as JSON",
        data=json.dumps(result, indent=2, ensure_ascii=False),
        file_name="travel_plan.json",
        mime="application/json",
    )
